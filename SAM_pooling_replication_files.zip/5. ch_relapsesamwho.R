# load packages 
  library(readstata13)
  library(mada)
  library(arm)
  library(data.table)
  library("writexl")
  library(ggplot2)
  library(ggrepel)
  library(tidyverse)

# clear environment 
  rm(list = ls())

# load files  
  muac = read.dta13("C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Data/ROC/muac_ch_relapsesamwho.dta")
  whz = read.dta13("C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Data/ROC/whz_ch_relapsesamwho.dta")
  waz = read.dta13("C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Data/ROC/waz_ch_relapsesamwho.dta")

#########################  
### DATA PREPARATION  ###
#########################  
# calculate fpr   
  whz$fpr = 1-whz$spec
  waz$fpr = 1-waz$spec
  muac$fpr = 1-muac$spec

# exclude studies without this outcome   
  muac = subset(muac, muac$names=="Isanaka et al. 2016" | muac$names=="Hitchings et al. 2022" | muac$names=="Garba et al. 2021" | muac$names=="Lelijveld et al. 2021" | 
                  muac$names=="Ciliberto et al. 2005" | muac$names=="Bhandari et al. 2016" | muac$names=="Binns et al. 2016" | muac$names=="Burrell et al. 2020" | 
                  muac$names=="John et al. 2018" | muac$names=="Adegoke et al. 2020" | muac$names=="Cazes et al. 2022" | muac$names=="Girma et al. 2022" | 
                  muac$names=="Lambedo et al. 2021" | muac$names=="Guesdon et al. 2021" | muac$names=="Kangas et al. 2019"| 
                  muac$names=="Hussein et al. 2021" | muac$names=="Kangas et al. 2023" | muac$names=="Daures et al. 2022" | muac$names=="Nahar et al. 2012" | 
                  muac$names=="Chaturvedi et al. 2018" | muac$names=="Burza et al. 2016")
  whz = subset(whz, whz$names=="Isanaka et al. 2016" | whz$names=="Hitchings et al. 2022" | whz$names=="Garba et al. 2021" | whz$names=="Lelijveld et al. 2021" | 
                 whz$names=="Ciliberto et al. 2005" | whz$names=="Bhandari et al. 2016" | whz$names=="Binns et al. 2016" | whz$names=="Burrell et al. 2020" | 
                 whz$names=="John et al. 2018" | whz$names=="Adegoke et al. 2020" | whz$names=="Cazes et al. 2022" | whz$names=="Girma et al. 2022" | 
                 whz$names=="Guesdon et al. 2021" | whz$names=="Kangas et al. 2019"| whz$names=="Hussein et al. 2021" | whz$names=="Kangas et al. 2023" | 
                 whz$names=="Daures et al. 2022" | whz$names=="Nahar et al. 2012" | whz$names=="Chaturvedi et al. 2018" | whz$names=="Burza et al. 2016")
  waz = subset(waz, waz$names=="Isanaka et al. 2016" | waz$names=="Hitchings et al. 2022" | waz$names=="Garba et al. 2021" | waz$names=="Lelijveld et al. 2021" | 
                 waz$names=="Ciliberto et al. 2005" | waz$names=="Bhandari et al. 2016" | waz$names=="Binns et al. 2016" | waz$names=="Burrell et al. 2020" | 
                 waz$names=="John et al. 2018" | waz$names=="Adegoke et al. 2020" | waz$names=="Cazes et al. 2022" | waz$names=="Girma et al. 2022" | 
                 waz$names=="Lambedo et al. 2021" | waz$names=="Guesdon et al. 2021" | waz$names=="Kangas et al. 2019" | waz$names=="Ashraf et al. 2012"| 
                 waz$names=="Hussein et al. 2021" | waz$names=="Kangas et al. 2023" | waz$names=="Daures et al. 2022" | waz$names=="Nahar et al. 2012" | 
                 waz$names=="Chaturvedi et al. 2018" | waz$names=="Burza et al. 2016")
  
# confirm names of studies for this outcome 
  names = (subset(muac, muac$cut == 11.5))$names
  names

  names1 = (subset(waz, waz$cut == -2))$names
  names1
  
# values of biomarkers to loop through
  vec.muac = unique(muac[,6])
  vec.whz  = unique(whz[,6])
  vec.waz  = unique(waz[,6])

##########################  
### Bivariate analysis ###
##########################
# bivariate model estimates pooled sensitivity and specificity at all cut-offs for each anthropometric criterion
# then output pooled estimates to excel to Excel. 

##############
#### MUAC ####
##############
# fit bivariate model at each cut-off 
  for(i in vec.muac) {
    assign(paste0("fit.muac.",round(i,1)), reitsma(subset(muac, muac$cut == i)))
  } 
  
# create a vector with the sensitivity and FPR estimates and 95% CIs at each cut-off
  sens11.5 = c(round(invlogit(fit.muac.11.5$coefficients[1]),2),  round(invlogit(confint(fit.muac.11.5)[1,1]),2), round(invlogit(confint(fit.muac.11.5)[1,2]),2))  
  spec11.5 = c(1-round(invlogit(fit.muac.11.5$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.11.5)[2,2]),2), 1-round(invlogit(confint(fit.muac.11.5)[2,1]),2))  
  
  sens11.6 = c(round(invlogit(fit.muac.11.6$coefficients[1]),2),  round(invlogit(confint(fit.muac.11.6)[1,1]),2), round(invlogit(confint(fit.muac.11.6)[1,2]),2))  
  spec11.6 = c(1-round(invlogit(fit.muac.11.6$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.11.6)[2,2]),2), 1-round(invlogit(confint(fit.muac.11.6)[2,1]),2))  
  
  sens11.7 = c(round(invlogit(fit.muac.11.7$coefficients[1]),2), round(invlogit(confint(fit.muac.11.7)[1,1]),2), round(invlogit(confint(fit.muac.11.7)[1,2]),2))  
  spec11.7 = c(1-round(invlogit(fit.muac.11.7$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.11.7)[2,2]),2), 1-round(invlogit(confint(fit.muac.11.7)[2,1]),2))  
  
  sens11.8 = c(round(invlogit(fit.muac.11.8$coefficients[1]),2),  round(invlogit(confint(fit.muac.11.8)[1,1]),2), round(invlogit(confint(fit.muac.11.8)[1,2]),2))  
  spec11.8 = c(1-round(invlogit(fit.muac.11.8$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.11.8)[2,2]),2), 1-round(invlogit(confint(fit.muac.11.8)[2,1]),2))  
  
  sens11.9 = c(round(invlogit(fit.muac.11.9$coefficients[1]),2), round(invlogit(confint(fit.muac.11.9)[1,1]),2), round(invlogit(confint(fit.muac.11.9)[1,2]),2))  
  spec11.9 = c(1-round(invlogit(fit.muac.11.9$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.11.9)[2,2]),2), 1-round(invlogit(confint(fit.muac.11.9)[2,1]),2))  
  
  sens12 = c(round(invlogit(fit.muac.12$coefficients[1]),2), round(invlogit(confint(fit.muac.12)[1,1]),2), round(invlogit(confint(fit.muac.12)[1,2]),2))  
  spec12 = c(1-round(invlogit(fit.muac.12$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12)[2,2]),2), 1-round(invlogit(confint(fit.muac.12)[2,1]),2))  
  
  sens12.1 = c(round(invlogit(fit.muac.12.1$coefficients[1]),2), round(invlogit(confint(fit.muac.12.1)[1,1]),2), round(invlogit(confint(fit.muac.12.1)[1,2]),2))  
  spec12.1 = c(1-round(invlogit(fit.muac.12.1$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.1)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.1)[2,1]),2))  
  
  sens12.2 = c(round(invlogit(fit.muac.12.2$coefficients[1]),2), round(invlogit(confint(fit.muac.12.2)[1,1]),2), round(invlogit(confint(fit.muac.12.2)[1,2]),2))  
  spec12.2 = c(1-round(invlogit(fit.muac.12.2$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.2)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.2)[2,1]),2))  
  
  sens12.3 = c(round(invlogit(fit.muac.12.3$coefficients[1]),2), round(invlogit(confint(fit.muac.12.3)[1,1]),2), round(invlogit(confint(fit.muac.12.3)[1,2]),2))  
  spec12.3 = c(1-round(invlogit(fit.muac.12.3$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.3)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.3)[2,1]),2))  
  
  sens12.4 = c(round(invlogit(fit.muac.12.4$coefficients[1]),2), round(invlogit(confint(fit.muac.12.4)[1,1]),2), round(invlogit(confint(fit.muac.12.4)[1,2]),2))  
  spec12.4 = c(1-round(invlogit(fit.muac.12.4$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.4)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.4)[2,1]),2))  
  
  sens12.5 = c(round(invlogit(fit.muac.12.5$coefficients[1]),2), round(invlogit(confint(fit.muac.12.5)[1,1]),2), round(invlogit(confint(fit.muac.12.5)[1,2]),2))  
  spec12.5 = c(1-round(invlogit(fit.muac.12.5$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.5)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.5)[2,1]),2))  
  
  sens12.6 = c(round(invlogit(fit.muac.12.6$coefficients[1]),2),  round(invlogit(confint(fit.muac.12.6)[1,1]),2), round(invlogit(confint(fit.muac.12.6)[1,2]),2))  
  spec12.6 = c(1-round(invlogit(fit.muac.12.6$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.6)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.6)[2,1]),2))  
  
  sens12.7 = c(round(invlogit(fit.muac.12.7$coefficients[1]),2),  round(invlogit(confint(fit.muac.12.7)[1,1]),2), round(invlogit(confint(fit.muac.12.7)[1,2]),2))  
  spec12.7 = c(1-round(invlogit(fit.muac.12.7$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.7)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.7)[2,1]),2))  
  
  sens12.8 = c(round(invlogit(fit.muac.12.8$coefficients[1]),2), round(invlogit(confint(fit.muac.12.8)[1,1]),2), round(invlogit(confint(fit.muac.12.8)[1,2]),2))  
  spec12.8 = c(1-round(invlogit(fit.muac.12.8$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.8)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.8)[2,1]),2))  
  
  sens12.9 = c(round(invlogit(fit.muac.12.9$coefficients[1]),2), round(invlogit(confint(fit.muac.12.9)[1,1]),2), round(invlogit(confint(fit.muac.12.9)[1,2]),2))  
  spec12.9 = c(1-round(invlogit(fit.muac.12.9$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.12.9)[2,2]),2), 1-round(invlogit(confint(fit.muac.12.9)[2,1]),2))  
  
  sens13 = c(round(invlogit(fit.muac.13$coefficients[1]),2), round(invlogit(confint(fit.muac.13)[1,1]),2), round(invlogit(confint(fit.muac.13)[1,2]),2))  
  spec13 = c(1-round(invlogit(fit.muac.13$coefficients[2]),2), 1-round(invlogit(confint(fit.muac.13)[2,2]),2), 1-round(invlogit(confint(fit.muac.13)[2,1]),2))  

# extract AUC 
  auc11.5 = AUC(fit.muac.11.5)$AUC
  auc11.6 = AUC(fit.muac.11.6)$AUC
  auc11.7 = AUC(fit.muac.11.7)$AUC
  auc11.8 = AUC(fit.muac.11.8)$AUC
  auc11.9 = AUC(fit.muac.11.9)$AUC
  auc12 = AUC(fit.muac.12)$AUC
  auc12.1 = AUC(fit.muac.12.1)$AUC
  auc12.2 = AUC(fit.muac.12.2)$AUC
  auc12.3 = AUC(fit.muac.12.3)$AUC
  auc12.4 = AUC(fit.muac.12.4)$AUC
  auc12.5 = AUC(fit.muac.12.5)$AUC
  auc12.6 = AUC(fit.muac.12.6)$AUC
  auc12.7 = AUC(fit.muac.12.7)$AUC
  auc12.8 = AUC(fit.muac.12.8)$AUC
  auc12.9 = AUC(fit.muac.12.9)$AUC
  auc13 = AUC(fit.muac.13)$AUC

# combine vectors into a data frame  
  muac.xls = data.frame(sens11.5, spec11.5, auc11.5, sens11.6, spec11.6, auc11.6, sens11.7, spec11.7, auc11.7,
                        sens11.8, spec11.8, auc11.8, sens11.9, spec11.9, auc11.9, sens12, spec12, auc12, 
                        sens12.1, spec12.1, auc12.1, sens12.2, spec12.2, auc12.2, sens12.3, spec12.3, auc12.3, 
                        sens12.4, spec12.4, auc12.4, sens12.5, spec12.5, auc12.5, sens12.6, spec12.6, auc12.6,
                        sens12.7, spec12.7, auc12.7, sens12.8, spec12.8, auc12.8, sens12.9, spec12.9, auc12.9,
                        sens13, spec13, auc13)
  data = data.table::transpose(muac.xls)
  data$names = c("sens", "spec", "auc")
  data$cut = c(11.5, 11.5, 11.5, 11.6, 11.6, 11.6, 11.7, 11.7, 11.7, 11.8, 11.8, 11.8, 11.9, 11.9, 11.9, 12, 12, 12, 
               12.1, 12.1, 12.1, 12.2, 12.2, 12.2, 12.3, 12.3, 12.3, 12.4, 12.4, 12.4, 12.5, 12.5, 12.5, 12.6, 12.6, 
               12.6, 12.7, 12.7, 12.7, 12.8, 12.8, 12.8, 12.9, 12.9, 12.9, 13, 13, 13)
  names(data) = c("coef", "lci", "uci", "measure", "cutoff")

# export data frame to excel to link with pretty results table  
  write_xlsx(data, "C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Out/SROC Raw/muac_ch_relapsesamwho.xlsx")

# create plotting data 
  muac.plot.sens = data.frame(sens11.5[1], sens11.6[1], sens11.7[1], sens11.8[1], sens11.9[1], sens12[1],
                              sens12.1[1], sens12.2[1], sens12.3[1], sens12.4[1], sens12.5[1], sens12.6[1],
                              sens12.7[1], sens12.8[1], sens12.9[1], sens13[1])
  muac.plot.sens = data.table::transpose(muac.plot.sens)
  muac.plot.sens$cut = c(11.5, 11.6, 11.7, 11.8, 11.9, 12, 12.1, 12.2, 12.3, 12.4, 12.5, 12.6, 12.7, 12.8, 12.9, 13)
  names(muac.plot.sens) = c("sens", "cut")
  
  muac.plot.spec = data.frame(spec11.5[1], spec11.6[1], spec11.7[1], spec11.8[1], spec11.9[1], spec12[1], 
                              spec12.1[1], spec12.2[1], spec12.3[1], spec12.4[1], spec12.5[1], spec12.6[1], 
                              spec12.7[1], spec12.8[1], spec12.9[1], spec13[1])
  muac.plot.spec = data.table::transpose(muac.plot.spec)
  muac.plot.spec$cut = c(11.5, 11.6, 11.7, 11.8, 11.9, 12, 12.1, 12.2, 12.3, 12.4, 12.5, 12.6, 12.7, 12.8, 12.9, 13)
  names(muac.plot.spec) = c("spec", "cut")
  
  muac.plot = merge(muac.plot.spec, muac.plot.sens, id=cut)
  muac.plot$fpr = 1-muac.plot$spec
  
  rm(list=ls(pattern="sens"))
  rm(list=ls(pattern="spec"))
  rm(list=ls(pattern="auc"))
  rm(data, muac.xls)
  
#############
#### WHZ ####
#############
  # fit bivariate model at each cut-off 
  for(i in vec.whz) {
    assign(paste0("fit.whz.",round(abs(i),1)), reitsma(subset(whz, whz$cut == i)))
  } 
  
# create a vector with the sensitivity and FRP estimates and 95% CIs at each cut-off
  sens0.5 = c(round(invlogit(fit.whz.0.5$coefficients[1]),2),  round(invlogit(confint(fit.whz.0.5)[1,1]),2), round(invlogit(confint(fit.whz.0.5)[1,2]),2))  
  spec0.5 = c(1-round(invlogit(fit.whz.0.5$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.0.5)[2,2]),2), 1-round(invlogit(confint(fit.whz.0.5)[2,1]),2))  
  
  sens0.6 = c(round(invlogit(fit.whz.0.6$coefficients[1]),2), round(invlogit(confint(fit.whz.0.6)[1,1]),2), round(invlogit(confint(fit.whz.0.6)[1,2]),2))  
  spec0.6 = c(1-round(invlogit(fit.whz.0.6$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.0.6)[2,2]),2), 1-round(invlogit(confint(fit.whz.0.6)[2,1]),2))  
  
  sens0.7 = c(round(invlogit(fit.whz.0.7$coefficients[1]),2), round(invlogit(confint(fit.whz.0.7)[1,1]),2), round(invlogit(confint(fit.whz.0.7)[1,2]),2))  
  spec0.7 = c(1-round(invlogit(fit.whz.0.7$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.0.7)[2,2]),2), 1-round(invlogit(confint(fit.whz.0.7)[2,1]),2))  
  
  sens0.8 = c(round(invlogit(fit.whz.0.8$coefficients[1]),2), round(invlogit(confint(fit.whz.0.8)[1,1]),2), round(invlogit(confint(fit.whz.0.8)[1,2]),2))  
  spec0.8 = c(1-round(invlogit(fit.whz.0.8$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.0.8)[2,2]),2), 1-round(invlogit(confint(fit.whz.0.8)[2,1]),2))  
  
  sens0.9 = c(round(invlogit(fit.whz.0.9$coefficients[1]),2), round(invlogit(confint(fit.whz.0.9)[1,1]),2), round(invlogit(confint(fit.whz.0.9)[1,2]),2))  
  spec0.9 = c(1-round(invlogit(fit.whz.0.9$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.0.9)[2,2]),2), 1-round(invlogit(confint(fit.whz.0.9)[2,1]),2))  
  
  sens1.0 = c(round(invlogit(fit.whz.1$coefficients[1]),2), round(invlogit(confint(fit.whz.1)[1,1]),2), round(invlogit(confint(fit.whz.1)[1,2]),2))  
  spec1.0 = c(1-round(invlogit(fit.whz.1$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1)[2,2]),2), 1-round(invlogit(confint(fit.whz.1)[2,1]),2))  
  
  sens1.1 = c(round(invlogit(fit.whz.1.1$coefficients[1]),2), round(invlogit(confint(fit.whz.1.1)[1,1]),2), round(invlogit(confint(fit.whz.1.1)[1,2]),2))  
  spec1.1 = c(1-round(invlogit(fit.whz.1.1$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.1)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.1)[2,1]),2))  
  
  sens1.2 = c(round(invlogit(fit.whz.1.2$coefficients[1]),2), round(invlogit(confint(fit.whz.1.2)[1,1]),2), round(invlogit(confint(fit.whz.1.2)[1,2]),2))  
  spec1.2 = c(1-round(invlogit(fit.whz.1.2$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.2)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.2)[2,1]),2))  
  
  sens1.3 = c(round(invlogit(fit.whz.1.3$coefficients[1]),2), round(invlogit(confint(fit.whz.1.3)[1,1]),2), round(invlogit(confint(fit.whz.1.3)[1,2]),2))  
  spec1.3 = c(1-round(invlogit(fit.whz.1.3$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.3)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.3)[2,1]),2))  
  
  sens1.4 = c(round(invlogit(fit.whz.1.4$coefficients[1]),2), round(invlogit(confint(fit.whz.1.4)[1,1]),2), round(invlogit(confint(fit.whz.1.4)[1,2]),2))  
  spec1.4 = c(1-round(invlogit(fit.whz.1.4$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.4)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.4)[2,1]),2))  
  
  sens1.5 = c(round(invlogit(fit.whz.1.5$coefficients[1]),2), round(invlogit(confint(fit.whz.1.5)[1,1]),2), round(invlogit(confint(fit.whz.1.5)[1,2]),2))  
  spec1.5 = c(1-round(invlogit(fit.whz.1.5$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.5)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.5)[2,1]),2))  
  
  sens1.6 = c(round(invlogit(fit.whz.1.6$coefficients[1]),2), round(invlogit(confint(fit.whz.1.6)[1,1]),2), round(invlogit(confint(fit.whz.1.6)[1,2]),2))  
  spec1.6 = c(1-round(invlogit(fit.whz.1.6$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.6)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.6)[2,1]),2))  
  
  sens1.7 = c(round(invlogit(fit.whz.1.7$coefficients[1]),2), round(invlogit(confint(fit.whz.1.7)[1,1]),2), round(invlogit(confint(fit.whz.1.7)[1,2]),2))  
  spec1.7 = c(1-round(invlogit(fit.whz.1.7$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.7)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.7)[2,1]),2))  
  
  sens1.8 = c(round(invlogit(fit.whz.1.8$coefficients[1]),2), round(invlogit(confint(fit.whz.1.8)[1,1]),2), round(invlogit(confint(fit.whz.1.8)[1,2]),2))  
  spec1.8 = c(1-round(invlogit(fit.whz.1.8$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.8)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.8)[2,1]),2))  
  
  sens1.9 = c(round(invlogit(fit.whz.1.9$coefficients[1]),2), round(invlogit(confint(fit.whz.1.9)[1,1]),2), round(invlogit(confint(fit.whz.1.9)[1,2]),2))  
  spec1.9 = c(1-round(invlogit(fit.whz.1.9$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.1.9)[2,2]),2), 1-round(invlogit(confint(fit.whz.1.9)[2,1]),2))  
  
  sens2 = c(round(invlogit(fit.whz.2$coefficients[1]),2), round(invlogit(confint(fit.whz.2)[1,1]),2), round(invlogit(confint(fit.whz.2)[1,2]),2))  
  spec2 = c(1-round(invlogit(fit.whz.2$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.2)[2,2]),2), 1-round(invlogit(confint(fit.whz.2)[2,1]),2))  
  
  sens2.1 = c(round(invlogit(fit.whz.2.1$coefficients[1]),2), round(invlogit(confint(fit.whz.2.1)[1,1]),2), round(invlogit(confint(fit.whz.2.1)[1,2]),2))  
  spec2.1 = c(1-round(invlogit(fit.whz.2.1$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.2.1)[2,2]),2), 1-round(invlogit(confint(fit.whz.2.1)[2,1]),2))

  sens2.2 = c(round(invlogit(fit.whz.2.2$coefficients[1]),2), round(invlogit(confint(fit.whz.2.2)[1,1]),2), round(invlogit(confint(fit.whz.2.2)[1,2]),2))  
  spec2.2 = c(1-round(invlogit(fit.whz.2.2$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.2.2)[2,2]),2), 1-round(invlogit(confint(fit.whz.2.2)[2,1]),2))
  
  sens2.3 = c(round(invlogit(fit.whz.2.3$coefficients[1]),2), round(invlogit(confint(fit.whz.2.3)[1,1]),2), round(invlogit(confint(fit.whz.2.3)[1,2]),2))  
  spec2.3 = c(1-round(invlogit(fit.whz.2.3$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.2.3)[2,2]),2), 1-round(invlogit(confint(fit.whz.2.3)[2,1]),2))
  
  sens2.4 = c(round(invlogit(fit.whz.2.4$coefficients[1]),2), round(invlogit(confint(fit.whz.2.4)[1,1]),2), round(invlogit(confint(fit.whz.2.4)[1,2]),2))  
  spec2.4 = c(1-round(invlogit(fit.whz.2.4$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.2.4)[2,2]),2), 1-round(invlogit(confint(fit.whz.2.4)[2,1]),2))
  
  sens2.5 = c(round(invlogit(fit.whz.2.5$coefficients[1]),2), round(invlogit(confint(fit.whz.2.5)[1,1]),2), round(invlogit(confint(fit.whz.2.5)[1,2]),2))  
  spec2.5 = c(1-round(invlogit(fit.whz.2.5$coefficients[2]),2), 1-round(invlogit(confint(fit.whz.2.5)[2,2]),2), 1-round(invlogit(confint(fit.whz.2.5)[2,1]),2))  

# extract AUC 
  auc0.5 = AUC(fit.whz.0.5)$AUC
  auc0.6 = AUC(fit.whz.0.6)$AUC
  auc0.7 = AUC(fit.whz.0.7)$AUC
  auc0.8 = AUC(fit.whz.0.8)$AUC
  auc0.9 = AUC(fit.whz.0.9)$AUC
  auc1 = AUC(fit.whz.1)$AUC
  auc1.1 = AUC(fit.whz.1.1)$AUC
  auc1.2 = AUC(fit.whz.1.2)$AUC
  auc1.3 = AUC(fit.whz.1.3)$AUC
  auc1.4 = AUC(fit.whz.1.4)$AUC
  auc1.5 = AUC(fit.whz.1.5)$AUC
  auc1.6 = AUC(fit.whz.1.6)$AUC
  auc1.7 = AUC(fit.whz.1.7)$AUC
  auc1.8 = AUC(fit.whz.1.8)$AUC
  auc1.9 = AUC(fit.whz.1.9)$AUC
  auc2 = AUC(fit.whz.2)$AUC
  auc2.1 = AUC(fit.whz.2.1)$AUC
  auc2.2 = AUC(fit.whz.2.2)$AUC
  auc2.3 = AUC(fit.whz.2.3)$AUC
  auc2.4 = AUC(fit.whz.2.4)$AUC
  auc2.5 = AUC(fit.whz.2.5)$AUC

# combine vectors into a data frame  
  whz.xls = data.frame(sens0.5, spec0.5, auc0.5, sens0.6, spec0.6, auc0.6, sens0.7, spec0.7, auc0.7, 
                       sens0.8, spec0.8, auc0.8, sens0.9, spec0.9, auc0.9, sens1.0, spec1.0, auc1, sens1.1, spec1.1, 
                       auc1.1, sens1.2, spec1.2, auc1.2, sens1.3, spec1.3, auc1.3, sens1.4, spec1.4, auc1.4, 
                       sens1.5, spec1.5, auc1.5, sens1.6, spec1.6, auc1.6, sens1.7, spec1.7, auc1.7, sens1.8,
                       spec1.8, auc1.8, sens1.9, spec1.9, auc1.9, sens2, spec2, auc2, sens2.1, spec2.1, auc2.1, 
                       sens2.2, spec2.2, auc2.2, sens2.3, spec2.3, auc2.3, sens2.4, spec2.4, auc2.5, sens2.5, 
                       spec2.5, auc2.5)
  data = data.table::transpose(whz.xls)
  data$names = c("sens", "spec", "auc")
  data$cut = c(-0.5, -0.5, -0.5, -0.6, -0.6, -0.6, -0.7, -0.7, -0.7, -0.8, -0.8, -0.8, -0.9, -0.9, -0.9, -1.0, -1.0, 
               -1.0, -1.1, -1.1, -1.1, -1.2, -1.2, -1.2, -1.3, -1.3, -1.3, -1.4, -1.4, -1.4, -1.50, -1.50, -1.50, 
               -1.6, -1.6, -1.6, -1.7, -1.7, -1.7, -1.8, -1.8, -1.8, -1.9, -1.9, -1.9, -2.0, -2.0, -2.0, -2.1, -2.1, 
               -2.1, -2.2, -2.2, -2.2, -2.3, -2.3, -2.3, -2.4, -2.4, -2.4, -2.5, -2.5, -2.5)
  names(data) = c("coef", "lci", "uci", "measure", "cutoff")

# export data frame to excel to link with pretty results table  
  write_xlsx(data, "C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Out/SROC Raw/whz_ch_relapsesamwho.xlsx")

# create plotting data 
  whz.plot.sens = data.frame(sens0.5[1], sens0.6[1], sens0.7[1], sens0.8[1], sens0.9[1], sens1.0[1], sens1.1[1], 
                             sens1.2[1], sens1.3[1], sens1.4[1], sens1.5[1], sens1.6[1], sens1.7[1], sens1.8[1], 
                             sens1.9[1], sens2[1], sens2.1[1], sens2.2[1], sens2.3[1], sens2.4[1], sens2.5[1])
  whz.plot.sens = data.table::transpose(whz.plot.sens)
  whz.plot.sens$cut = c(-0.5, -0.6, -0.7, -0.8, -0.9, -1.0, -1.1, -1.2, -1.3, -1.4, -1.5, -1.6, -1.7, -1.8,
                        -1.9, -2.0, -2.1, -2.2, -2.3, -2.4, -2.5)
  names(whz.plot.sens) = c("sens", "cut")
  
  whz.plot.spec = data.frame(spec0.5[1], spec0.6[1], spec0.7[1], spec0.8[1], spec0.9[1], spec1.0[1], spec1.1[1], 
                             spec1.2[1], spec1.3[1], spec1.4[1], spec1.5[1], spec1.6[1], spec1.7[1], spec1.8[1], 
                             spec1.9[1], spec2[1], spec2.1[1], spec2.2[1], spec2.3[1], spec2.4[1], spec2.5[1])
  whz.plot.spec = data.table::transpose(whz.plot.spec)
  whz.plot.spec$cut = c(-0.5, -0.6, -0.7, -0.8, -0.9, -1.0, -1.1, -1.2, -1.3, -1.4, -1.5, -1.6, -1.7, -1.8,
                        -1.9, -2.0, -2.1, -2.2, -2.3, -2.4, -2.5)
  names(whz.plot.spec) = c("spec", "cut")
  
  whz.plot = merge(whz.plot.spec, whz.plot.sens, id=cut)
  whz.plot$fpr = 1-whz.plot$spec

  rm(list=ls(pattern="sens"))
  rm(list=ls(pattern="spec"))
  rm(list=ls(pattern="auc"))
  rm(data, whz.xls)
  
#############
#### WAZ ####
#############
# fit bivariate model at each cut-off 
  for(i in vec.waz) {
    assign(paste0("fit.waz.",round(abs(i),1)), reitsma(subset(waz, waz$cut == i)))
  } 
  
# create a vector with the sensitivity and FRP estimates and 95% CIs at each cut-off
  sens0.5 = c(round(invlogit(fit.waz.0.5$coefficients[1]),2), round(invlogit(confint(fit.waz.0.5)[1,1]),2), round(invlogit(confint(fit.waz.0.5)[1,2]),2))  
  spec0.5 = c(1-round(invlogit(fit.waz.0.5$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.0.5)[2,2]),2), 1-round(invlogit(confint(fit.waz.0.5)[2,1]),2))  
  
  sens0.6 = c(round(invlogit(fit.waz.0.6$coefficients[1]),2), round(invlogit(confint(fit.waz.0.6)[1,1]),2), round(invlogit(confint(fit.waz.0.6)[1,2]),2))  
  spec0.6 = c(1-round(invlogit(fit.waz.0.6$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.0.6)[2,2]),2), 1-round(invlogit(confint(fit.waz.0.6)[2,1]),2))  
  
  sens0.7 = c(round(invlogit(fit.waz.0.7$coefficients[1]),2), round(invlogit(confint(fit.waz.0.7)[1,1]),2), round(invlogit(confint(fit.waz.0.7)[1,2]),2))  
  spec0.7 = c(1-round(invlogit(fit.waz.0.7$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.0.7)[2,2]),2), 1-round(invlogit(confint(fit.waz.0.7)[2,1]),2))  
  
  sens0.8 = c(round(invlogit(fit.waz.0.8$coefficients[1]),2), round(invlogit(confint(fit.waz.0.8)[1,1]),2), round(invlogit(confint(fit.waz.0.8)[1,2]),2))  
  spec0.8 = c(1-round(invlogit(fit.waz.0.8$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.0.8)[2,2]),2), 1-round(invlogit(confint(fit.waz.0.8)[2,1]),2))  
  
  sens0.9 = c(round(invlogit(fit.waz.0.9$coefficients[1]),2), round(invlogit(confint(fit.waz.0.9)[1,1]),2), round(invlogit(confint(fit.waz.0.9)[1,2]),2))  
  spec0.9 = c(1-round(invlogit(fit.waz.0.9$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.0.9)[2,2]),2), 1-round(invlogit(confint(fit.waz.0.9)[2,1]),2))  
  
  sens1.0 = c(round(invlogit(fit.waz.1$coefficients[1]),2), round(invlogit(confint(fit.waz.1)[1,1]),2), round(invlogit(confint(fit.waz.1)[1,2]),2))  
  spec1.0 = c(1-round(invlogit(fit.waz.1$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1)[2,2]),2), 1-round(invlogit(confint(fit.waz.1)[2,1]),2))  
  
  sens1.1 = c(round(invlogit(fit.waz.1.1$coefficients[1]),2), round(invlogit(confint(fit.waz.1.1)[1,1]),2), round(invlogit(confint(fit.waz.1.1)[1,2]),2))  
  spec1.1 = c(1-round(invlogit(fit.waz.1.1$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.1)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.1)[2,1]),2))  
  
  sens1.2 = c(round(invlogit(fit.waz.1.2$coefficients[1]),2), round(invlogit(confint(fit.waz.1.2)[1,1]),2), round(invlogit(confint(fit.waz.1.2)[1,2]),2))  
  spec1.2 = c(1-round(invlogit(fit.waz.1.2$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.2)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.2)[2,1]),2))  
  
  sens1.3 = c(round(invlogit(fit.waz.1.3$coefficients[1]),2), round(invlogit(confint(fit.waz.1.3)[1,1]),2), round(invlogit(confint(fit.waz.1.3)[1,2]),2))  
  spec1.3 = c(1-round(invlogit(fit.waz.1.3$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.3)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.3)[2,1]),2))  
  
  sens1.4 = c(round(invlogit(fit.waz.1.4$coefficients[1]),2), round(invlogit(confint(fit.waz.1.4)[1,1]),2), round(invlogit(confint(fit.waz.1.4)[1,2]),2))  
  spec1.4 = c(1-round(invlogit(fit.waz.1.4$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.4)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.4)[2,1]),2))  
  
  sens1.5 = c(round(invlogit(fit.waz.1.5$coefficients[1]),2), round(invlogit(confint(fit.waz.1.5)[1,1]),2), round(invlogit(confint(fit.waz.1.5)[1,2]),2))  
  spec1.5 = c(1-round(invlogit(fit.waz.1.5$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.5)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.5)[2,1]),2))  
  
  sens1.6 = c(round(invlogit(fit.waz.1.6$coefficients[1]),2), round(invlogit(confint(fit.waz.1.6)[1,1]),2), round(invlogit(confint(fit.waz.1.6)[1,2]),2))  
  spec1.6 = c(1-round(invlogit(fit.waz.1.6$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.6)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.6)[2,1]),2))  
  
  sens1.7 = c(round(invlogit(fit.waz.1.7$coefficients[1]),2), round(invlogit(confint(fit.waz.1.7)[1,1]),2), round(invlogit(confint(fit.waz.1.7)[1,2]),2))  
  spec1.7 = c(1-round(invlogit(fit.waz.1.7$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.7)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.7)[2,1]),2))  
  
  sens1.8 = c(round(invlogit(fit.waz.1.8$coefficients[1]),2), round(invlogit(confint(fit.waz.1.8)[1,1]),2), round(invlogit(confint(fit.waz.1.8)[1,2]),2))  
  spec1.8 = c(1-round(invlogit(fit.waz.1.8$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.8)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.8)[2,1]),2))  
  
  sens1.9 = c(round(invlogit(fit.waz.1.9$coefficients[1]),2), round(invlogit(confint(fit.waz.1.9)[1,1]),2), round(invlogit(confint(fit.waz.1.9)[1,2]),2))  
  spec1.9 = c(1-round(invlogit(fit.waz.1.9$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.1.9)[2,2]),2), 1-round(invlogit(confint(fit.waz.1.9)[2,1]),2))  
  
  sens2 = c(round(invlogit(fit.waz.2$coefficients[1]),2), round(invlogit(confint(fit.waz.2)[1,1]),2), round(invlogit(confint(fit.waz.2)[1,2]),2))  
  spec2 = c(1-round(invlogit(fit.waz.2$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.2)[2,2]),2), 1-round(invlogit(confint(fit.waz.2)[2,1]),2))  
  
  sens2.1 = c(round(invlogit(fit.waz.2.1$coefficients[1]),2), round(invlogit(confint(fit.waz.2.1)[1,1]),2), round(invlogit(confint(fit.waz.2.1)[1,2]),2))  
  spec2.1 = c(1-round(invlogit(fit.waz.2.1$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.2.1)[2,2]),2), 1-round(invlogit(confint(fit.waz.2.1)[2,1]),2))
  
  sens2.2 = c(round(invlogit(fit.waz.2.2$coefficients[1]),2), round(invlogit(confint(fit.waz.2.2)[1,1]),2), round(invlogit(confint(fit.waz.2.2)[1,2]),2))  
  spec2.2 = c(1-round(invlogit(fit.waz.2.2$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.2.2)[2,2]),2), 1-round(invlogit(confint(fit.waz.2.2)[2,1]),2))
  
  sens2.3 = c(round(invlogit(fit.waz.2.3$coefficients[1]),2), round(invlogit(confint(fit.waz.2.3)[1,1]),2), round(invlogit(confint(fit.waz.2.3)[1,2]),2))  
  spec2.3 = c(1-round(invlogit(fit.waz.2.3$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.2.3)[2,2]),2), 1-round(invlogit(confint(fit.waz.2.3)[2,1]),2))
  
  sens2.4 = c(round(invlogit(fit.waz.2.4$coefficients[1]),2), round(invlogit(confint(fit.waz.2.4)[1,1]),2), round(invlogit(confint(fit.waz.2.4)[1,2]),2))  
  spec2.4 = c(1-round(invlogit(fit.waz.2.4$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.2.4)[2,2]),2), 1-round(invlogit(confint(fit.waz.2.4)[2,1]),2))
  
  sens2.5 = c(round(invlogit(fit.waz.2.5$coefficients[1]),2), round(invlogit(confint(fit.waz.2.5)[1,1]),2), round(invlogit(confint(fit.waz.2.5)[1,2]),2))  
  spec2.5 = c(1-round(invlogit(fit.waz.2.5$coefficients[2]),2), 1-round(invlogit(confint(fit.waz.2.5)[2,2]),2), 1-round(invlogit(confint(fit.waz.2.5)[2,1]),2))  

# extract AUC 
  auc0.5 = AUC(fit.waz.0.5)$AUC
  auc0.6 = AUC(fit.waz.0.6)$AUC
  auc0.7 = AUC(fit.waz.0.7)$AUC
  auc0.8 = AUC(fit.waz.0.8)$AUC
  auc0.9 = AUC(fit.waz.0.9)$AUC
  auc1 = AUC(fit.waz.1)$AUC
  auc1.1 = AUC(fit.waz.1.1)$AUC
  auc1.2 = AUC(fit.waz.1.2)$AUC
  auc1.3 = AUC(fit.waz.1.3)$AUC
  auc1.4 = AUC(fit.waz.1.4)$AUC
  auc1.5 = AUC(fit.waz.1.5)$AUC
  auc1.6 = AUC(fit.waz.1.6)$AUC
  auc1.7 = AUC(fit.waz.1.7)$AUC
  auc1.8 = AUC(fit.waz.1.8)$AUC
  auc1.9 = AUC(fit.waz.1.9)$AUC
  auc2 = AUC(fit.waz.2)$AUC
  auc2.1 = AUC(fit.waz.2.1)$AUC
  auc2.2 = AUC(fit.waz.2.2)$AUC
  auc2.3 = AUC(fit.waz.2.3)$AUC
  auc2.4 = AUC(fit.waz.2.4)$AUC
  auc2.5 = AUC(fit.waz.2.5)$AUC

# combine vectors into a data frame  
  waz.xls = data.frame(sens0.5, spec0.5, auc0.5, sens0.6, spec0.6, auc0.6, sens0.7, spec0.7, auc0.7, 
                       sens0.8, spec0.8, auc0.8, sens0.9, spec0.9, auc0.9, sens1.0, spec1.0, auc1, sens1.1, spec1.1, 
                       auc1.1, sens1.2, spec1.2, auc1.2, sens1.3, spec1.3, auc1.3, sens1.4, spec1.4, auc1.4, 
                       sens1.5, spec1.5, auc1.5, sens1.6, spec1.6, auc1.6, sens1.7, spec1.7, auc1.7, sens1.8, spec1.8, 
                       auc1.8, sens1.9, spec1.9, auc1.9, sens2, spec2, auc2, sens2.1, spec2.1, auc2.1, sens2.2, 
                       spec2.2, auc2.2, sens2.3, spec2.3, auc2.3, sens2.4, spec2.4, auc2.5, sens2.5, spec2.5, auc2.5)
  data = data.table::transpose(waz.xls)
  data$names = c("sens", "spec", "auc")
  data$cut = c(-0.5, -0.5, -0.5, -0.6, -0.6, -0.6, -0.7, -0.7, -0.7, -0.8, -0.8, -0.8, -0.9, -0.9, -0.9, -1.0, -1.0, 
               -1.0, -1.1, -1.1, -1.1, -1.2, -1.2, -1.2, -1.3, -1.3, -1.3, -1.4, -1.4, -1.4, -1.50, -1.50, -1.50, 
               -1.6, -1.6, -1.6, -1.7, -1.7, -1.7, -1.8, -1.8, -1.8, -1.9, -1.9, -1.9, -2.0, -2.0, -2.0, -2.1, -2.1, 
               -2.1, -2.2, -2.2, -2.2, -2.3, -2.3, -2.3, -2.4, -2.4, -2.4, -2.5, -2.5, -2.5)
  names(data) = c("coef", "lci", "uci", "measure", "cutoff")

# export data frame to excel to link with pretty results table  
  write_xlsx(data, "C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Out/SROC Raw/waz_ch_relapsesamwho.xlsx")

# create plotting data 
  waz.plot.sens = data.frame(sens0.5[1], sens0.6[1], sens0.7[1], sens0.8[1], sens0.9[1], sens1.0[1], sens1.1[1], 
                             sens1.2[1], sens1.3[1], sens1.4[1], sens1.5[1], sens1.6[1], sens1.7[1], sens1.8[1], 
                             sens1.9[1], sens2[1], sens2.1[1], sens2.2[1], sens2.3[1], sens2.4[1], sens2.5[1])
  waz.plot.sens = data.table::transpose(waz.plot.sens)
  waz.plot.sens$cut = c(-0.5, -0.6, -0.7, -0.8, -0.9, -1.0, -1.1, -1.2, -1.3, -1.4, -1.5, -1.6, -1.7, -1.8,
                        -1.9, -2.0, -2.1, -2.2, -2.3, -2.4, -2.5)
  names(waz.plot.sens) = c("sens", "cut")
  
  waz.plot.spec = data.frame(spec0.5[1], spec0.6[1], spec0.7[1], spec0.8[1], spec0.9[1], spec1.0[1], spec1.1[1], 
                             spec1.2[1], spec1.3[1], spec1.4[1], spec1.5[1], spec1.6[1], spec1.7[1], spec1.8[1], 
                             spec1.9[1], spec2[1], spec2.1[1], spec2.2[1], spec2.3[1], spec2.4[1], spec2.5[1])
  waz.plot.spec = data.table::transpose(waz.plot.spec)
  waz.plot.spec$cut = c(-0.5, -0.6, -0.7, -0.8, -0.9, -1.0, -1.1, -1.2, -1.3, -1.4, -1.5, -1.6, -1.7, -1.8,
                        -1.9, -2.0, -2.1, -2.2, -2.3, -2.4, -2.5)
  names(waz.plot.spec) = c("spec", "cut")
  
  waz.plot = merge(waz.plot.spec, waz.plot.sens, id=cut)
  waz.plot$fpr = 1-waz.plot$spec

  rm(list=ls(pattern="sens"))
  rm(list=ls(pattern="spec"))
  rm(list=ls(pattern="auc"))
  rm(data, waz.xls)

###############################
###   PLOT POOLED RESULTS   ###
###############################
  
tiff("C:/Users/lbliznashka/Dropbox/SAM Relapse/Analysis/Out/SROC figures/ch_relapsesamwho.tiff", units="in", width=11, height=10, res=600, compression = 'lzw')
  
colors = c("WAZ"="orange", "WHZ"="black", "MUAC"="blue")
ggplot(whz.plot, aes(fpr, sens, label=cut)) + 
  geom_line(aes(col="WHZ"), lwd=1) + 
  geom_point(aes(col="WHZ")) + 
  geom_text_repel(max.overlaps = Inf, box.padding = 0.5, col="gray", nudge_y = 0.01) +
  
  geom_line(data=waz.plot, aes(x=fpr, y=sens, col="WAZ"), lwd=1) +
  geom_point(data=waz.plot, aes(x=fpr, y=sens, col="WAZ")) +
  geom_text_repel(data=waz.plot, max.overlaps = Inf, box.padding = 0.5, col="gray", nudge_y = 0.01) +
  
  geom_line(data=muac.plot, aes(x=fpr, y=sens, col="MUAC"), lwd=1) +
  geom_point(data=muac.plot, aes(x=fpr, y=sens, col="MUAC")) +
  geom_text_repel(data=muac.plot, max.overlaps = Inf, box.padding = 0.5, col="gray", nudge_y = 0.01) +
  
  scale_color_manual(values = colors, name="Legend") +
  labs(y = "Sensitivity", x = "1-specificity", 
       title="A. SAM relapse") +
  xlim(0, 1) + ylim(0, 1) +
  theme_minimal() 
dev.off()
